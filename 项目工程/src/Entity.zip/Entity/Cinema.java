package Entity;

import java.util.List;

public class Cinema {

    private int cinemaId;

    private String cinemaName;//影院名

    private String location;//影院位置

    private List<Room> roomList = null;

    public List<Room> getRoomList() {
        return roomList;
    }

    public String getCinemaName() {
        return cinemaName;
    }

    public int getCinemaId() {
        return cinemaId;
    }

    public void setCinemaName(String cinemaName) {
        this.cinemaName = cinemaName;
    }

    public void setCinemaId(int cinemaId) {
        this.cinemaId = cinemaId;
    }

    public void setRoomList(List<Room> roomList) {
        this.roomList = roomList;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location=location;
    }

}
