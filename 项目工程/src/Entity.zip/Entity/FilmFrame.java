package Entity;

import java.util.*;
public class FilmFrame {

    private Film onFilm;//上映的电影

    private Date timeOn;//开始播放时间

    private Date timeOff;//结束时间

    private double price;

    private Seat[][] seatStatus = null;

    public void setTimeOn(Date timeOn) {
        this.timeOn = timeOn;
    }

    public void setTimeOff(Date timeOff) {
        this.timeOff = timeOff;
    }

    public void setOnFilm(Film onFilm) {
        this.onFilm = onFilm;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setSeatStatus(Seat[][] seatStatus) {
        this.seatStatus = seatStatus;
    }

    public Date getTimeOff() {
        return timeOff;
    }

    public double getPrice() {
        return price;
    }

    public Seat[][] getSeatStatus() {
        return seatStatus;
    }

    public Date getTimeOn() {
        return timeOn;
    }

    public Film getOnFilm() {
        return onFilm;
    }

}
