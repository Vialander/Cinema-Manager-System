package Entity;

import java.util.*;
public class Room {

    private int id;//厅号

    private String nameOfCinema;

    private int idOfCinema;

    private Seat[][] seat = null;

    private List<FilmFrame> scheduleTime = null;

    public void setScheduleTime(List<FilmFrame> scheduleTime) {
        this.scheduleTime = scheduleTime;
    }

    public List<FilmFrame> getScheduleTime() {
        return scheduleTime;
    }

    public void setIdOfCinema(int idOfCinema) {
        this.idOfCinema = idOfCinema;
    }

    public int getIdOfCinema() {
        return idOfCinema;
    }

    public void setNameOfCinema(String nameOfCinema) {
        this.nameOfCinema = nameOfCinema;
    }

    public void setSeatStatus(Seat[][] seatStatus) {
        this.seat = seatStatus;
    }

    public Seat[][] getSeatStatus() {
        return seat;
    }

    public String getNameOfCinema() {
        return nameOfCinema;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id=id;
    }

}
