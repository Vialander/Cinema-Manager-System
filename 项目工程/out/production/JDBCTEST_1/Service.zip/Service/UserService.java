package Service;


import Entity.*;

import java.lang.reflect.Modifier;

/**
 * 用户服务类接口
 */

public interface UserService {


    /**
     * 用户服务之购买
     */
    public abstract void buy(User thisUser, FilmFrame thisFilmFrame);

    /**
     * 列出所有影院
     */
    public abstract void showCinema();

    /**
     * 选择某影院里面包含的所有上架电影
     */
    public abstract void showSelectedFilmsInCinema(Cinema cinema);

    /**
     * 显示所有已经上架的电影
     */
    public abstract void showSelectedFilms();


    /**
     * 根据已经上架电影跳转到选择界面
     *
     */

    public abstract void selectSelectedFilms(Film thisFilm);

    /**
     * 进入选座界面
     */
    public abstract void getIntoChoose(User thisUser,FilmFrame thisFilmFrame);

    /**
     * 手动选座
     */
    //public abstract void Choose(int row,int column,int FilmFrame);

    /**
     * 登陆
     * @return User
     */
    public abstract User login();

    /**
     * 注册
     */
    public abstract void regist();

}
