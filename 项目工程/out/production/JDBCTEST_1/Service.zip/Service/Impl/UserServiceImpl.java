package Service.Impl;

import Dao.Impl.*;
import Dao.*;
import Entity.*;
import Service.UserService;
import java.text.DateFormat;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



/**
 * 用户服务实现类
 */
public class UserServiceImpl implements UserService {

    /**
     * 用户服务之购买
     */
    public  void buy(User thisUser, FilmFrame thisFilmFrame){
        UserDao userDao = new UserDaoImpl();
        thisUser.setUserAccount(thisUser.getUserAccount() - thisFilmFrame.getPrice());
        userDao.updateUser(thisUser);
    }

    /**
     * 列出所有影院
     */
    public  void showCinema(){
        List<Cinema> cinemaList = new ArrayList<Cinema>();
        CinemaDao cinemaDao = new CinemaDaoImpl();
        cinemaList = cinemaDao.getAllCinema();
        System.out.println("电影院\t地点");
        for(Cinema cinema:cinemaList){
            System.out.print(cinema.getCinemaName());
            System.out.print("\t");
            System.out.print(cinema.getLocation());
            System.out.print("\n");
        }
    }

    /**
     * 选择某影院里面包含的所有上架电影
     */
    public  void showSelectedFilmsInCinema(Cinema cinema){
       // List<FilmFrame> filmFrameList = new ArrayList<FilmFrame>();
       // FilmFrameDao filmFrameDao = new FilmFrameDaoImpl();
//        filmFrameList = filmFrameDao.selectFilmFrame("select * from filmframe where cinema_id = ?",param);
        List<Film> selectedFilmList = new ArrayList<Film>();
        FilmDao selectedFilmDao = new SelectedFilmDaoImpl();
        Object[] param = {cinema.getCinemaId()};

        selectedFilmList = selectedFilmDao.selectFilm("select * from selectedFilm where film_id in (select onfilm->'$.filmId' from filmframe where cinema_id =  ?)",param);
        System.out.println("电影\t主演\t评分\t类型\t时长\t/国家\t上映日期");
        for(Film film:selectedFilmList){
            System.out.print(film.getFilmName());
            System.out.print("\t");
            System.out.print(film.getMainActor());
            System.out.print("\t");
            System.out.print(film.getScore());
            System.out.print("\t");
            System.out.print(film.getType());
            System.out.print("\t");
            System.out.print(film.getTimeLong());
            System.out.print("\t");
            System.out.print(film.getCountry());
            System.out.print("\t");
            System.out.print(film.getStartTime());
            System.out.print("\n");
        }
    }




    /**
     * 显示已经上架电影
     */
    public void showSelectedFilms(){
        List<Film> selectedFilmList = new ArrayList<Film>();
        FilmDao selectedFilmDao = new SelectedFilmDaoImpl();
        selectedFilmList = selectedFilmDao.getAllFilm();
        System.out.println("电影\t主演\t评分\t类型\t时长\t/国家\t上映日期");
        for(Film film:selectedFilmList){
            System.out.print(film.getFilmName());
            System.out.print("\t");
            System.out.print(film.getMainActor());
            System.out.print("\t");
            System.out.print(film.getScore());
            System.out.print("\t");
            System.out.print(film.getType());
            System.out.print("\t");
            System.out.print(film.getTimeLong());
            System.out.print("\t");
            System.out.print(film.getCountry());
            System.out.print("\t");
            System.out.print(film.getStartTime());
            System.out.print("\n");
        }
    }

    /**
     * 选择已经显示的已上架电影(根据已上架电影选择场次)
     */
    public void selectSelectedFilms(Film thisFilm){
        List<FilmFrame> filmFrameList = new ArrayList<FilmFrame>();
        FilmFrameDao filmFrameDao = new FilmFrameDaoImpl();
//        net.sf.json.JSONObject jsonObject1 = net.sf.json.JSONObject.fromObject(thisFilm);
//        Object[] param = {jsonObject1.toString()};
//        select * from t1 where attributes_json->'$.P2PUser'=1 AND attributes_json->'$.PONUser'=12;
        Object[] param = {thisFilm.getFilmId()};
        filmFrameList = filmFrameDao.selectFilmFrame("select * from filmframe where onfilm->'$.filmId' = ?",param);
        DateFormat dateFormat = DateFormat.getDateTimeInstance();
        System.out.println("电影\t\t主演\t\t类型\t时长\t/国家\t影院\t影厅\t场次");
        for(FilmFrame filmFrame:filmFrameList){
            System.out.print(filmFrame.getOnFilm().getFilmName());
            System.out.print("\t\t");
            System.out.print(filmFrame.getOnFilm().getMainActor());
            System.out.print("\t\t");
            System.out.print(filmFrame.getOnFilm().getType());
            System.out.print("\t");
            System.out.print(filmFrame.getOnFilm().getTimeLong());
            System.out.print("\t");
            System.out.print(filmFrame.getOnFilm().getCountry());
            System.out.print("\t");
            System.out.print(filmFrame.getCinemaId());
            System.out.print("\t");
            System.out.print(filmFrame.getRoomId() + "号厅");
            System.out.print("\t");
            System.out.print(dateFormat.format(filmFrame.getTimeOn()) + "~"+dateFormat.format(filmFrame.getTimeOff()));
            System.out.print("\n");
        }

    }
    /**
     * 进入选座界面
     */
    public void getIntoChoose(User thisUser,FilmFrame thisFilmFrame) {
        if (thisUser.getUserAccount() < thisFilmFrame.getPrice()) {
            System.out.print("余额不足，请您先充值");
        } else {
            System.out.println("该场次情况：");
            Seat[][] seats = thisFilmFrame.getSeatStatus();
            int row = thisFilmFrame.getSeatRows();
            int column = thisFilmFrame.getSeatColomns();
            for (int i = 0; i < thisFilmFrame.getSeatRows(); i++) {
                for (int j = 0; j < thisFilmFrame.getSeatColomns(); j++) {
                    if (seats[i][j].getStatus() == 0) {
                        System.out.println("✗");
                    } else if (seats[i][j].getStatus() == 1) {
                        System.out.println("☆");
                    } else {
                        System.out.println("★");
                    }

                }
            }
            Scanner input = new Scanner(System.in);
            System.out.println("请选择第几排：");
            row = input.nextInt();
            System.out.println("请选择第几列：");
            column = input.nextInt();
            while (true) {
                if (row > 0 && row <= thisFilmFrame.getSeatRows() && column > 0 && column <= thisFilmFrame.getSeatColomns() && seats[row][column].getStatus() != 0 && seats[row][column].getStatus() != 2) {
                    break;
                } else {
                    System.out.println("该非法！请重新选择第几排：");
                    row = input.nextInt();
                    System.out.println("请选择第几列：");
                    column = input.nextInt();
                }
            }
            seats[row][column].setStatus(2);
            seats[row][column].setUserId(thisUser.getUserId());
            seats[row][column].setUserName(thisUser.getUserName());
            thisFilmFrame.setSeatStatus(seats);
            FilmFrameDao filmFrameDao = new FilmFrameDaoImpl();
            filmFrameDao.updateFilmFrame(thisFilmFrame);
            this.buy(thisUser,thisFilmFrame);
            System.out.println("选座成功");
        }
    }

    /**
     * 登陆
     * @return User //登陆之用户
     */
    public  User login(){
        String username = "",userpass = "";
        Scanner input = new Scanner(System.in);
        System.out.println("----------------------范神牛逼电影系统-----------------");
        System.out.println("顾客登录");

        UserDao userDao = new UserDaoImpl();
        List<User> userList = new ArrayList<User>();
        userList = userDao.getAllUser();
        User thisUser = null;

        if(userList.size() != 0) {
            boolean flag = true;
            while(flag) {
                System.out.println("请输入用户名:");
                username = input.next();

                System.out.println("请输入密码:");
                userpass = input.next();

                for (User user : userList) {
                    if (user.getUserName().equals(username) && user.getUserPassword().equals(userpass)) {
                        System.out.println("登陆成功");
                        flag = false;
                        thisUser = user;
                    } else {
                        System.out.println("登陆失败,请重新输入");
                    }
                }
            }
        }else{
            System.out.println("一个用户也tm没有这软件凉凉了啊");
        }

        return thisUser;
    }

    /**
     * 注册
     */
    public  void regist(){
        String username = "",userpass = "",userpass2 = "";
        Scanner input = new Scanner(System.in);
        System.out.println("----------------------范神牛逼电影系统-----------------");
        System.out.println("顾客注册");

        UserDao userDao = new UserDaoImpl();
        List<User> userList = new ArrayList<User>();
        userList = userDao.getAllUser();
        User thisUser = null;


        boolean flag = true;
        boolean flag2 = true;
        while(flag) {
            flag2=true;
            System.out.println("请输入用户名:");
            username = input.next();

            System.out.println("请输入密码:");
            userpass = input.next();

            System.out.println("请再次输入密码:");
            userpass2 = input.next();
            if(!(userpass.equals(userpass2))) {
                System.out.println("两次输入密码不一致");
            } else{
                for (User user : userList) {
                    if (user.getUserName().equals(username) ) {
                        System.out.println("用户名重复");
                        System.out.println("请重新注册");
                        flag2 = false;
                        break;
                    }
                }
                if(flag2 == true){
                    System.out.println("请输入账户余额:");
                    double account = input.nextDouble();
                    thisUser = new User();
                    thisUser = new User(userList.size() + 1,username,userpass,account);
                    userDao.addUser(thisUser);
                    System.out.println("注册成功");
                    flag = false;
                }
            }
        }
    }
}
